/**
 * Central Brand and Link Configuration for YULKY GAMER
 *
 * REPLACE THE VALUES BELOW WITH YOUR REAL SOCIAL MEDIA AND CONTENT LINKS.
 * All changes in this file immediately reflect across the entire website.
 */

export const SITE_CONFIG = {
  brand: {
    name: 'YULKY GAMER',
    tagline: 'Minecraft Adventures. Epic Challenges. Unlimited Imagination.',
    heroHeadline: 'ENTER THE WORLD OF YULKY GAMER',
    shortBio:
      'High-octane Minecraft gameplay, survival sagas, extreme experiments, and cinematic world-building adventures created for true gaming explorers.',
    missionQuote:
      'Every world has a story. Every challenge creates an adventure.',
    missionStatement:
      'Driven by curiosity and passion for sandbox worlds, Yulky Gamer pushes Minecraft beyond standard boundaries—crafting adrenaline-filled survival epics, jaw-dropping mega-structures, and creative challenges that bring players together.',
  },

  // --------------------------------------------------------------------------
  // OFFICIAL CHANNELS & DESTINATIONS
  // --------------------------------------------------------------------------
  socials: {
    // Official YouTube Channel link
    youtube: 'https://www.youtube.com/@BESTERGAMERZ99',
    youtubeSubscribe: 'https://www.youtube.com/@BESTERGAMERZ99?sub_confirmation=1',
    youtubeShorts: 'https://www.youtube.com/@BESTERGAMERZ99/shorts',

    // Official Instagram profile link
    instagram: 'https://instagram.com/yulkygamer',

    // Official Discord community server link
    discord: 'https://discord.gg/yulkygamer',

    // Optional X / Twitter link
    twitter: 'https://x.com/yulkygamer',
  },

  // --------------------------------------------------------------------------
  // FEATURED GAMEPLAY VIDEO (Video 1 from official upload list)
  // --------------------------------------------------------------------------
  featuredVideo: {
    id: 'ryi4ZWwvjWM',
    title: 'FIRST DAY in Minecraft BATTLE PIE! Server Itna HARD Hoga Socha Nahi Tha… 💀🔥Episode #1',
    description:
      'Starting our brand new journey on the intense Minecraft Battle Pie server! The first day survival trial pushed our skills to the absolute limit with dangerous traps, ruthless mobs, and unexpected encounters.',
    category: 'Minecraft Survival' as const,
    youtubeUrl: 'https://youtu.be/ryi4ZWwvjWM',
    youtubeEmbedId: 'ryi4ZWwvjWM',
  },

  // --------------------------------------------------------------------------
  // COLLABORATION & INQUIRIES
  // --------------------------------------------------------------------------
  contact: {
    businessEmail: 'contact@yulkygamer.com',
    collaborationsOpen: true,
  },

  // --------------------------------------------------------------------------
  // BRAND COLOR PALETTE
  // --------------------------------------------------------------------------
  theme: {
    bgBlack: '#050505',
    bgDark: '#101010',
    neonRed: '#FF0033',
    neonCyan: '#00E5FF',
  },
};

