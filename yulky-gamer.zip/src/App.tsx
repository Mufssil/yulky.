import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { FeaturedVideo } from './components/FeaturedVideo';
import { VideoGallery } from './components/VideoGallery';
import { ShortsArena } from './components/ShortsArena';
import { Downloads } from './components/Downloads';
import { GetMinecraft } from './components/GetMinecraft';
import { Community } from './components/Community';
import { LogoShowcase } from './components/LogoShowcase';
import { Footer } from './components/Footer';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('home');

  useEffect(() => {
    const sectionIds = [
      'home',
      'about',
      'videos',
      'shorts',
      'resources',
      'get-minecraft',
      'community',
    ];

    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200;

      for (let i = sectionIds.length - 1; i >= 0; i--) {
        const id = sectionIds[i];
        const el = document.getElementById(id);
        if (el && el.offsetTop <= scrollPosition) {
          setActiveSection(id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#050505] text-[#E2E8F0] selection:bg-[#00E5FF]/20 selection:text-[#00E5FF] font-body relative">
      {/* 1. Premium Navigation Bar */}
      <Navbar activeSection={activeSection} />

      {/* Main Content Sections (Ordered strictly per Requirement 9) */}
      <main>
        {/* 2. Cinematic Hero Section with Supplied Sword Image */}
        <Hero />

        {/* 3. About Yulky Gamer */}
        <About />

        {/* 4. Featured Long-Form Video */}
        <FeaturedVideo />

        {/* 5. Latest Long-Form Videos (The 3 Exact Videos) */}
        <VideoGallery />

        {/* 6. Shorts Arena (The 4 Exact YouTube Shorts) */}
        <ShortsArena />

        {/* 7. Minecraft Resource Hub (Modrinth Mods, Packs, Maps, Add-ons) */}
        <Downloads />

        {/* 8. Get Minecraft Section (PC/Mac, Mobile Official Releases) */}
        <GetMinecraft />

        {/* 9. Community and YouTube Subscription Section */}
        <Community />

        {/* 10. Brand Logo Showcase */}
        <LogoShowcase />
      </main>

      {/* 11. Footer */}
      <Footer />
    </div>
  );
}
