import React from 'react';
import { Compass, Beaker, Swords, Shield, Zap, Sparkles } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';

export const About: React.FC = () => {
  const pillars = [
    {
      id: 'pillar-1',
      title: 'Minecraft Adventures',
      description:
        'Immersive survival playthroughs, extreme dimension exploration, and cinematic world voyages across perilous hardcore environments.',
      icon: Compass,
      accentColor: '#00E5FF',
      highlight: 'Deep exploration & world-building',
    },
    {
      id: 'pillar-2',
      title: 'Creative Experiments',
      description:
        'Unconventional game mechanics, complex redstone contraptions, physics-testing setups, and discovering hidden sandbox mysteries.',
      icon: Beaker,
      accentColor: '#FF0033',
      highlight: 'Boundary-pushing redstone & physics',
    },
    {
      id: 'pillar-3',
      title: 'Epic Challenges',
      description:
        'High-stakes constraints, single-heart hardcore trials, extreme custom rule-sets, and adrenaline-charged boss conquests.',
      icon: Swords,
      accentColor: '#00E5FF',
      highlight: 'High stakes & hardcore mastery',
    },
  ];

  return (
    <section id="about" className="relative py-24 bg-[#080A10] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-start max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#00E5FF] mb-2 font-heading">
            <span>Identity & Core Pillars</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-4">
            BEYOND THE GAME
          </h2>
          <p className="text-base sm:text-lg text-zinc-300 leading-relaxed font-medium">
            YULKY GAMER is a dedicated gaming creator platform centered on high-energy Minecraft
            storytelling, mind-bending experiments, and impossible survival conquests.
          </p>
        </div>

        {/* 2-Column Split: Visual Card + Narrative */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16 items-center">
          {/* Visual Showcase Card: Minecraft Netherite & Cyan Cyber Aesthetic */}
          <div className="lg:col-span-5 relative group">
            <div className="relative rounded-2xl bg-gradient-to-br from-[#121622] via-[#0E1118] to-[#07090E] p-8 border border-white/10 overflow-hidden shadow-2xl">
              {/* Decorative Geometric Grid & Energy Accent */}
              <div className="absolute top-0 right-0 w-48 h-48 bg-[#00E5FF]/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#FF0033]/10 rounded-full blur-3xl pointer-events-none" />

              {/* Stylized Minecraft Block Composition */}
              <div className="relative z-10 flex flex-col items-center text-center p-4">
                <div className="w-28 h-28 rounded-2xl bg-[#080B12] border border-[#00E5FF]/40 p-4 mb-6 relative flex items-center justify-center shadow-lg shadow-[#00E5FF]/15 group-hover:border-[#00E5FF] transition-colors">
                  <div className="absolute inset-1 rounded-xl bg-gradient-to-br from-[#00E5FF]/20 to-transparent pointer-events-none" />
                  <Shield className="w-12 h-12 text-[#00E5FF]" />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#FF0033] rounded-sm flex items-center justify-center">
                    <Zap className="w-2.5 h-2.5 text-white" />
                  </div>
                </div>

                <h3 className="font-heading text-xl font-bold text-white mb-2">
                  THE SANDBOX ODYSSEY
                </h3>
                <p className="text-xs text-zinc-400 leading-relaxed max-w-sm mb-6">
                  Every video is engineered with passion for cinematography, intense pacing,
                  and unyielding curiosity. No repetitive grinding—only crafted moments of thrill and wonder.
                </p>

                <div className="w-full pt-4 border-t border-zinc-800 flex justify-around text-xs text-zinc-300 font-medium">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" /> Hardcore Survival
                  </span>
                  <span aria-hidden="true" className="text-zinc-600">·</span>
                  <span className="flex items-center gap-1">
                    <Zap className="w-3.5 h-3.5 text-[#FF0033]" /> Creative Redstone
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Narrative Content */}
          <div className="lg:col-span-7 space-y-6">
            <div className="p-6 sm:p-8 rounded-2xl bg-[#0D1018] border border-white/5 space-y-4">
              <h3 className="font-heading text-lg sm:text-xl font-bold text-white">
                CREATING UNFORGETTABLE GAMING MOMENTS
              </h3>
              <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
                In a world of infinite blocks, the only constraint is your courage to push past the ordinary.
                YULKY GAMER transforms classic sandbox survival into cinematic adventures—tackling brutal
                game modifiers, testing viral Minecraft urban legends, and fabricating jaw-dropping mega-bases block by block.
              </p>
              <p className="text-zinc-400 text-sm sm:text-base leading-relaxed">
                Whether diving into uncharted dimensions or inventing new ways to conquer ancient trials,
                the goal is always the same: inspiring creativity, sharing technical gaming ingenuity,
                and entertaining players around the globe.
              </p>
            </div>
          </div>
        </div>

        {/* 3 Core Pillars Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {pillars.map((pillar, idx) => {
            const Icon = pillar.icon;
            const isRed = pillar.accentColor === '#FF0033';
            return (
              <div
                key={pillar.id}
                className="group relative rounded-xl bg-[#0D1018] hover:bg-[#121622] p-7 border border-white/5 hover:border-white/15 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Clean Icon Box */}
                  <div
                    className={`w-12 h-12 rounded-lg flex items-center justify-center mb-6 transition-transform group-hover:scale-105 ${
                      isRed
                        ? 'bg-[#FF0033]/10 text-[#FF0033] border border-[#FF0033]/30'
                        : 'bg-[#00E5FF]/10 text-[#00E5FF] border border-[#00E5FF]/30'
                    }`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>

                  {/* Clean Editorial Title */}
                  <h3 className="font-heading text-lg font-bold text-white mb-2 group-hover:text-[#00E5FF] transition-colors">
                    {pillar.title}
                  </h3>

                  <p className="text-sm text-zinc-400 leading-relaxed mb-6">
                    {pillar.description}
                  </p>
                </div>

                {/* Subtext highlight */}
                <div className="pt-4 border-t border-zinc-800/80 text-xs text-zinc-400 flex items-center justify-between">
                  <span>{pillar.highlight}</span>
                  <span className="text-zinc-500 font-mono text-[11px]">0{idx + 1}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
