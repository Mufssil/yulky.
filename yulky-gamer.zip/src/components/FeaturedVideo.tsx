import React, { useState } from 'react';
import { Play, ExternalLink, ShieldCheck, X, Youtube } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';

export const FeaturedVideo: React.FC = () => {
  const [isPlayingModal, setIsPlayingModal] = useState(false);
  const [thumbSrc, setThumbSrc] = useState(
    `https://img.youtube.com/vi/${SITE_CONFIG.featuredVideo.id}/maxresdefault.jpg`
  );
  const featured = SITE_CONFIG.featuredVideo;

  const handleThumbError = () => {
    // Fall back to hqdefault if maxres does not exist
    setThumbSrc(`https://img.youtube.com/vi/${featured.id}/hqdefault.jpg`);
  };

  return (
    <section className="relative py-20 bg-[#080B12] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#00E5FF] mb-2 font-heading">
              <Youtube className="w-4 h-4 text-[#FF0033]" />
              <span>Official Premiere</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white">
              FEATURED GAMEPLAY
            </h2>
          </div>
          <p className="text-sm text-zinc-400 max-w-md">
            The opening chapter of our Minecraft Battle Pie survival challenge.
          </p>
        </div>

        {/* Featured Video Marquee Card */}
        <div className="relative rounded-2xl bg-[#0F131D] border border-white/10 overflow-hidden shadow-2xl group hover:border-[#00E5FF]/40 transition-all duration-300">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left: Thumbnail & Play Trigger */}
            <div className="lg:col-span-7 relative aspect-video bg-[#07090F] overflow-hidden flex items-center justify-center">
              <img
                src={thumbSrc}
                alt={featured.title}
                onError={handleThumbError}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="eager"
              />

              {/* Contrast Scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent pointer-events-none" />

              {/* Video Title Overlay on Thumbnail */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-zinc-300 z-10">
                <span className="font-heading font-bold text-white text-xs sm:text-sm bg-black/80 px-2.5 py-1 rounded backdrop-blur-sm border border-white/10">
                  {featured.category}
                </span>
                <span className="bg-[#FF0033] text-white px-2.5 py-1 rounded font-bold text-xs">
                  Episode #1
                </span>
              </div>

              {/* Big Centered Play Button */}
              <button
                type="button"
                onClick={() => setIsPlayingModal(true)}
                className="relative z-20 w-20 h-20 rounded-full bg-gradient-to-tr from-[#FF0033] to-[#ff2b54] text-white flex items-center justify-center shadow-xl shadow-[#FF0033]/40 group-hover:scale-110 transition-transform duration-300 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#00E5FF]"
                aria-label={`Play ${featured.title}`}
              >
                <Play className="w-8 h-8 fill-current ml-1" />
                <span className="sr-only">Play Video</span>
              </button>
            </div>

            {/* Right: Metadata, Description & Action */}
            <div className="lg:col-span-5 p-8 sm:p-10 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-xs font-semibold text-zinc-400">
                  <span className="text-[#00E5FF] font-heading">Battle Pie Series</span>
                  <span aria-hidden="true">·</span>
                  <span>Episode #1</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-zinc-400">Official Upload</span>
                </div>

                <h3 className="font-heading text-xl sm:text-2xl font-extrabold text-white leading-snug group-hover:text-[#00E5FF] transition-colors">
                  {featured.title}
                </h3>

                <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
                  {featured.description}
                </p>

                <div className="pt-2 flex items-center gap-2 text-xs text-zinc-400">
                  <ShieldCheck className="w-4 h-4 text-[#00E5FF]" />
                  <span>Direct link to YouTube creator channel</span>
                </div>
              </div>

              <div className="pt-8 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => setIsPlayingModal(true)}
                  className="inline-flex items-center gap-2 px-6 py-3 text-xs font-bold uppercase tracking-wider text-white bg-[#FF0033] hover:bg-[#d60029] rounded-md transition-all shadow-md shadow-[#FF0033]/25"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Watch Gameplay</span>
                </button>

                <a
                  href={featured.youtubeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-5 py-3 text-xs font-bold uppercase tracking-wider text-zinc-300 bg-white/5 hover:bg-white/10 hover:text-white rounded-md transition-colors border border-white/10"
                >
                  <span>Open in YouTube</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal for Embed */}
      {isPlayingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative w-full max-w-4xl bg-[#090C12] border border-white/20 rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <h4 className="font-heading text-sm text-white font-bold truncate pr-4">
                {featured.title}
              </h4>
              <button
                type="button"
                onClick={() => setIsPlayingModal(false)}
                className="p-1 text-zinc-400 hover:text-white rounded-md hover:bg-white/10"
                aria-label="Close video"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="aspect-video w-full bg-black">
              <iframe
                title={featured.title}
                src={`https://www.youtube.com/embed/${featured.youtubeEmbedId}?autoplay=1`}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
