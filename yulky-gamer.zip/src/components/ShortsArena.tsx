import React, { useState } from 'react';
import { Play, ExternalLink, Flame, Youtube, X } from 'lucide-react';
import { SHORTS_VIDEOS } from '../data/videos';
import { ShortItem } from '../types';
import { SITE_CONFIG } from '../config/siteConfig';

export const ShortsArena: React.FC = () => {
  const [activeShort, setActiveShort] = useState<ShortItem | null>(null);
  const [thumbErrors, setThumbErrors] = useState<Record<string, boolean>>({});

  const handleThumbError = (id: string) => {
    setThumbErrors((prev) => ({ ...prev, [id]: true }));
  };

  return (
    <section id="shorts" className="relative py-24 bg-[#080B12] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#FF0033] mb-2 font-heading">
              <Flame className="w-4 h-4 fill-current" />
              <span>Bite-Sized Moments</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white">
              SHORTS ARENA
            </h2>
            <p className="text-sm text-zinc-400 mt-2 max-w-xl">
              Quick hacks, sound secrets, invulnerable mob tests, and fast-paced prison escapes in 60 seconds.
            </p>
          </div>

          {/* View All Shorts Button */}
          <div className="shrink-0">
            <a
              href={SITE_CONFIG.socials.youtubeShorts}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF0033] to-[#cc0029] hover:from-[#ff1a47] hover:to-[#FF0033] rounded-md transition-all shadow-md shadow-[#FF0033]/20"
            >
              <Youtube className="w-4 h-4 fill-current" />
              <span>View All Shorts</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-70" />
            </a>
          </div>
        </div>

        {/* 9:16 Shorts Grid / Carousel */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {SHORTS_VIDEOS.map((short, idx) => {
            const hasError = thumbErrors[short.id];
            const imgSrc = hasError ? short.hqThumbnail : short.maxresThumbnail;

            return (
              <article
                key={short.id}
                className="group relative rounded-xl bg-[#0D111A] border border-white/10 hover:border-[#FF0033]/60 transition-all duration-300 overflow-hidden flex flex-col justify-between shadow-xl hover:-translate-y-1.5"
              >
                {/* 9:16 Aspect Ratio Frame */}
                <div className="relative aspect-[9/16] bg-[#07090F] overflow-hidden">
                  <img
                    src={imgSrc}
                    alt={short.title}
                    onError={() => handleThumbError(short.id)}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />

                  {/* Gradient Scrim for readable text */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/20 to-black/40" />

                  {/* Top Shorts Badge */}
                  <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 px-2 py-0.5 rounded bg-black/75 border border-white/10 text-[10px] font-heading font-bold text-white">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FF0033]" />
                    <span>#Shorts</span>
                  </div>

                  <div className="absolute top-2.5 right-2.5 text-[10px] font-mono text-zinc-300 bg-black/75 px-1.5 py-0.5 rounded">
                    0{idx + 1}
                  </div>

                  {/* Centered Play Trigger */}
                  <button
                    type="button"
                    onClick={() => setActiveShort(short)}
                    className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/35 transition-colors focus-visible:outline-none"
                    aria-label={`Play Short: ${short.title}`}
                  >
                    <div className="w-12 h-12 rounded-full bg-[#FF0033] text-white flex items-center justify-center shadow-lg transform scale-90 group-hover:scale-110 transition-transform">
                      <Play className="w-5 h-5 fill-current ml-0.5" />
                    </div>
                  </button>

                  {/* Bottom Title & Action in 9:16 Card */}
                  <div className="absolute bottom-0 inset-x-0 p-3 sm:p-4 space-y-2 pointer-events-auto">
                    <h3 className="font-heading text-xs sm:text-sm font-bold text-white line-clamp-2 leading-snug group-hover:text-[#00E5FF] transition-colors">
                      {short.title}
                    </h3>

                    <div className="pt-1 flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setActiveShort(short)}
                        className="flex-1 py-1.5 px-2 text-[10px] sm:text-xs font-bold uppercase rounded bg-[#FF0033] hover:bg-[#d60029] text-white transition-colors text-center"
                      >
                        Watch Short
                      </button>
                      <a
                        href={short.youtubeUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded bg-white/10 hover:bg-white/20 text-white transition-colors"
                        aria-label="Open on YouTube Shorts"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>

      {/* Modal Shorts Player */}
      {activeShort && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative w-full max-w-sm sm:max-w-md bg-[#090C12] border border-white/20 rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between p-3.5 border-b border-white/10">
              <h4 className="font-heading text-xs text-white font-bold truncate pr-3">
                {activeShort.title}
              </h4>
              <button
                type="button"
                onClick={() => setActiveShort(null)}
                className="p-1 text-zinc-400 hover:text-white rounded-md hover:bg-white/10"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="aspect-[9/16] w-full max-h-[75vh] bg-black">
              <iframe
                title={activeShort.title}
                src={`https://www.youtube.com/embed/${activeShort.embedId}?autoplay=1`}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
            <div className="p-3 bg-[#0B0E16] flex justify-between items-center text-xs">
              <a
                href={activeShort.youtubeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#00E5FF] hover:underline flex items-center gap-1 font-semibold"
              >
                <span>Open in YouTube App</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <button
                type="button"
                onClick={() => setActiveShort(null)}
                className="text-zinc-400 hover:text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
