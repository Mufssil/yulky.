import React from 'react';
import { Sparkles, Terminal } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';

export const LogoShowcase: React.FC = () => {
  return (
    <section className="relative py-24 bg-[#080B12] border-t border-white/5 overflow-hidden">
      {/* Background Minecraft Atmosphere */}
      <div className="absolute inset-0 bg-minecraft-grid opacity-20 pointer-events-none" />

      {/* Atmospheric Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-gradient-to-r from-[#00E5FF]/10 via-transparent to-[#FF0033]/10 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#00E5FF] mb-2 font-heading">
            <Sparkles className="w-4 h-4" />
            <span>Brand Identity</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl font-black text-white">
            THE YULKY GAMER EMBLEM
          </h2>
          <p className="text-sm text-zinc-400 mt-2">
            Forged in obsidian. Infused with cybernetic redstone and cyan kinetic charge.
          </p>
        </div>

        {/* Central Logo Pedestal Showcase */}
        <div className="relative max-w-3xl mx-auto">
          {/* Minecraft-Style Cyber Pedestal Frame */}
          <div className="relative rounded-2xl bg-gradient-to-b from-[#111624] to-[#080B12] border border-white/10 p-8 sm:p-14 shadow-2xl flex flex-col items-center justify-center text-center overflow-hidden">
            {/* Corner Decorative Blocks */}
            <div className="absolute top-3 left-3 w-3 h-3 bg-[#00E5FF]/60" />
            <div className="absolute top-3 right-3 w-3 h-3 bg-[#FF0033]/60" />
            <div className="absolute bottom-3 left-3 w-3 h-3 bg-[#FF0033]/60" />
            <div className="absolute bottom-3 right-3 w-3 h-3 bg-[#00E5FF]/60" />

            {/* Glowing Rune Pedestal Platform */}
            <div className="relative mb-8 group">
              {/* Pulsing Under-pedestal Glow */}
              <div className="absolute -inset-4 bg-gradient-to-r from-[#00E5FF]/20 via-[#FF0033]/20 to-[#00E5FF]/20 rounded-2xl blur-xl opacity-75 group-hover:opacity-100 transition-opacity" />

              {/* Pedestal Box */}
              <div className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-2xl bg-[#06080D] border-2 border-[#00E5FF]/40 p-4 flex flex-col items-center justify-center shadow-[0_0_30px_rgba(0,229,255,0.2)] group-hover:border-[#00E5FF] transition-all">
                {/* Minecraft Styled Geometric Monogram */}
                <svg
                  viewBox="0 0 100 100"
                  className="w-24 h-24 sm:w-28 sm:h-28 filter drop-shadow-[0_0_8px_#00E5FF]"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  {/* Outer Cyber Octagon / Shield */}
                  <polygon
                    points="30,5 70,5 95,30 95,70 70,95 30,95 5,70 5,30"
                    stroke="#1C2436"
                    strokeWidth="3"
                    fill="#0A0E17"
                  />
                  {/* Letter Y stylized as an obsidian dagger */}
                  <polygon points="25,25 35,25 50,50 65,25 75,25 56,58 56,75 44,75 44,58" fill="#00E5FF" />
                  {/* Crimson Accent Gem at Core */}
                  <polygon points="50,45 55,52 50,60 45,52" fill="#FF0033" />
                  {/* Neon Cyan Highlights */}
                  <line x1="15" y1="50" x2="25" y2="50" stroke="#00E5FF" strokeWidth="2" />
                  <line x1="75" y1="50" x2="85" y2="50" stroke="#00E5FF" strokeWidth="2" />
                </svg>

                <div className="absolute bottom-2 text-[10px] font-heading font-extrabold tracking-widest text-[#00E5FF]">
                  EST. 2024
                </div>
              </div>
            </div>

            {/* Custom Typographic Wordmark */}
            <div className="space-y-2">
              <h3 className="font-heading text-3xl sm:text-5xl font-black tracking-widest text-white leading-none">
                YULKY <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00E5FF] to-[#00b4d8]">GAMER</span>
              </h3>
              <p className="font-body text-sm sm:text-base text-zinc-400 font-semibold tracking-wider uppercase">
                MINECRAFT CREATOR &bull; ADVENTURE EXPERIMENTS &bull; CHALLENGES
              </p>
            </div>

            {/* Micro Details Bar */}
            <div className="mt-8 pt-6 border-t border-zinc-800/80 w-full flex flex-wrap items-center justify-center gap-6 text-xs text-zinc-400 font-mono">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#00E5FF]" /> Primary Cyan (#00E5FF)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#FF0033]" /> Neon Red (#FF0033)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#050505] border border-zinc-700" /> Obsidian Base (#050505)
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
