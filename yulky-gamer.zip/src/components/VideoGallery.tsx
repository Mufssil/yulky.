import React, { useState } from 'react';
import { Play, ExternalLink, Youtube, X } from 'lucide-react';
import { LONG_FORM_VIDEOS } from '../data/videos';
import { VideoItem } from '../types';
import { SITE_CONFIG } from '../config/siteConfig';

export const VideoGallery: React.FC = () => {
  const [activeModalVideo, setActiveModalVideo] = useState<VideoItem | null>(null);
  const [thumbErrors, setThumbErrors] = useState<Record<string, boolean>>({});

  const handleThumbError = (id: string) => {
    setThumbErrors((prev) => ({ ...prev, [id]: true }));
  };

  return (
    <section id="videos" className="relative py-24 bg-[#050505] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#00E5FF] mb-2 font-heading">
              <Youtube className="w-4 h-4 text-[#FF0033]" />
              <span>Official YouTube Catalog</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white">
              LATEST VIDEOS
            </h2>
            <p className="text-sm text-zinc-400 mt-2 max-w-xl">
              Watch full-length Minecraft survival adventures, hardcore trials, and impossible parkour challenges.
            </p>
          </div>

          {/* Watch More on Channel Button */}
          <div className="shrink-0">
            <a
              href={SITE_CONFIG.socials.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-zinc-200 bg-white/5 hover:bg-[#FF0033] hover:text-white rounded-md border border-white/10 hover:border-transparent transition-all shadow-sm"
            >
              <Youtube className="w-4 h-4 fill-current" />
              <span>Watch More on Channel</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-70" />
            </a>
          </div>
        </div>

        {/* 3-Column Video Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {LONG_FORM_VIDEOS.map((video, idx) => {
            const hasError = thumbErrors[video.id];
            const imgSrc = hasError ? video.hqThumbnail : video.maxresThumbnail;

            return (
              <article
                key={video.id}
                className="group rounded-xl bg-[#0D1019] border border-white/10 hover:border-[#00E5FF]/50 transition-all duration-300 overflow-hidden flex flex-col justify-between hover:-translate-y-1.5 shadow-xl hover:shadow-[0_0_25px_rgba(0,229,255,0.15)]"
              >
                <div>
                  {/* Thumbnail Visual Container with Image & Hover Play Overlay */}
                  <div className="relative aspect-video bg-[#07090F] overflow-hidden">
                    <img
                      src={imgSrc}
                      alt={video.title}
                      onError={() => handleThumbError(video.id)}
                      loading="lazy"
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />

                    {/* Gradient Overlay for Legibility */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />

                    {/* Category Label */}
                    <div className="absolute top-3 left-3 text-[11px] font-heading font-semibold text-white bg-black/80 px-2.5 py-0.5 rounded border border-white/10 backdrop-blur-sm">
                      {video.category || 'Minecraft'}
                    </div>

                    {/* Episode Marker */}
                    <div className="absolute top-3 right-3 text-[11px] font-mono font-bold text-white bg-[#FF0033]/90 px-2 py-0.5 rounded">
                      #0{idx + 1}
                    </div>

                    {/* Centered Play Button on Hover */}
                    <button
                      type="button"
                      onClick={() => setActiveModalVideo(video)}
                      className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/45 transition-colors focus-visible:outline-none"
                      aria-label={`Play ${video.title}`}
                    >
                      <div className="w-14 h-14 rounded-full bg-[#FF0033] text-white flex items-center justify-center shadow-lg transform scale-90 group-hover:scale-110 transition-transform">
                        <Play className="w-6 h-6 fill-current ml-0.5" />
                      </div>
                    </button>
                  </div>

                  {/* Card Content */}
                  <div className="p-5 space-y-3">
                    <div className="flex items-center gap-2 text-[11px] text-zinc-400 font-medium">
                      <span className="text-[#00E5FF] font-semibold">Official Upload</span>
                      <span aria-hidden="true">·</span>
                      <span>HD 60FPS</span>
                    </div>

                    <h3 className="font-heading text-base font-bold text-white group-hover:text-[#00E5FF] transition-colors line-clamp-2 leading-snug">
                      {video.title}
                    </h3>

                    <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                      {video.description}
                    </p>
                  </div>
                </div>

                {/* Card Action Controls */}
                <div className="p-5 pt-0 grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveModalVideo(video)}
                    className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold uppercase rounded bg-[#FF0033] hover:bg-[#d60029] text-white transition-colors"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Watch Here</span>
                  </button>

                  <a
                    href={video.youtubeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white border border-white/10 transition-colors"
                  >
                    <span>YouTube</span>
                    <ExternalLink className="w-3 h-3 opacity-60" />
                  </a>
                </div>
              </article>
            );
          })}
        </div>
      </div>

      {/* Modal Video Player */}
      {activeModalVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative w-full max-w-4xl bg-[#090C12] border border-white/20 rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <h4 className="font-heading text-sm text-white font-bold truncate pr-4">
                {activeModalVideo.title}
              </h4>
              <button
                type="button"
                onClick={() => setActiveModalVideo(null)}
                className="p-1 text-zinc-400 hover:text-white rounded-md hover:bg-white/10"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="aspect-video w-full bg-black">
              <iframe
                title={activeModalVideo.title}
                src={`https://www.youtube.com/embed/${activeModalVideo.embedId}?autoplay=1`}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
