import React from 'react';
import { ArrowUp, Youtube, Instagram, MessageSquare, ExternalLink } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Videos', href: '#videos' },
    { label: 'Shorts Arena', href: '#shorts' },
    { label: 'Resource Hub', href: '#resources' },
    { label: 'Get Minecraft', href: '#get-minecraft' },
    { label: 'Community', href: '#community' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="relative bg-[#030407] border-t border-white/10 text-zinc-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-start">
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded bg-[#101520] border border-[#00E5FF]/40 flex items-center justify-center font-heading font-black text-xs text-[#00E5FF]">
                YG
              </div>
              <span className="font-heading text-xl font-black tracking-wider text-white">
                {SITE_CONFIG.brand.name}
              </span>
            </div>

            <p className="text-sm text-zinc-400 leading-relaxed max-w-sm">
              Official website for YouTube gaming creator Yulky Gamer (@BESTERGAMERZ99). Minecraft survival series, extreme challenges, daily shorts, and community resources.
            </p>

            {/* Social Icons Strip */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href={SITE_CONFIG.socials.youtube}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Official YouTube Channel"
                className="w-9 h-9 rounded-lg bg-white/5 hover:bg-[#FF0033] hover:text-white flex items-center justify-center text-zinc-300 transition-colors"
              >
                <Youtube className="w-4 h-4 fill-current" />
              </a>
              <a
                href={SITE_CONFIG.socials.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram Profile"
                className="w-9 h-9 rounded-lg bg-white/5 hover:bg-[#E1306C] hover:text-white flex items-center justify-center text-zinc-300 transition-colors"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={SITE_CONFIG.socials.discord}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Discord Community"
                className="w-9 h-9 rounded-lg bg-white/5 hover:bg-[#00E5FF] hover:text-black flex items-center justify-center text-zinc-300 transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="font-heading text-xs font-bold uppercase tracking-wider text-white">
              Navigation
            </h4>
            <ul className="grid grid-cols-2 gap-2 text-sm">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    onClick={(e) => handleNavClick(e, link.href)}
                    className="hover:text-[#00E5FF] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Back to Top & Direct Channel Link */}
          <div className="md:col-span-3 flex flex-col md:items-end justify-between h-full space-y-6">
            <button
              type="button"
              onClick={scrollToTop}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-zinc-300 bg-white/5 hover:bg-white/10 hover:text-white rounded-lg transition-colors border border-white/5"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-4 h-4 text-[#00E5FF]" />
            </button>

            <div className="text-left md:text-right text-xs text-zinc-400">
              <span className="block mb-1">Official YouTube:</span>
              <a
                href={SITE_CONFIG.socials.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#00E5FF] hover:underline font-mono"
              >
                @BESTERGAMERZ99
              </a>
            </div>
          </div>
        </div>

        {/* Legal & Copyright */}
        <div className="mt-12 pt-6 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-400 gap-4">
          <p>
            &copy; {currentYear} {SITE_CONFIG.brand.name}. All rights reserved.
          </p>
          <p className="text-[11px] text-zinc-500">
            Minecraft is a registered trademark of Mojang Synergies AB. This website is an independent creator portfolio.
          </p>
        </div>
      </div>
    </footer>
  );
};
