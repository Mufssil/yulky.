import React, { useState } from 'react';
import { Youtube, Instagram, MessageSquare, Send, CheckCircle2, Sparkles, ExternalLink, Flame } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';

export const Community: React.FC = () => {
  const [challengeText, setChallengeText] = useState('');
  const [gamerTag, setGamerTag] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmitChallenge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!challengeText.trim()) return;
    setSubmitted(true);
  };

  const socialCards = [
    {
      name: 'YouTube Channel',
      handle: '@BESTERGAMERZ99',
      role: 'Main Video HQ & Daily Shorts',
      url: SITE_CONFIG.socials.youtube,
      icon: Youtube,
      accentColor: '#FF0033',
      buttonText: 'VISIT CHANNEL',
    },
    {
      name: 'Instagram',
      handle: '@yulkygamer',
      role: 'Behind the Scenes & Clips',
      url: SITE_CONFIG.socials.instagram,
      icon: Instagram,
      accentColor: '#E1306C',
      buttonText: 'Follow on IG',
    },
    {
      name: 'Discord Server',
      handle: 'Yulky Community Hub',
      role: 'Chat, Events & Pack Feedback',
      url: SITE_CONFIG.socials.discord,
      icon: MessageSquare,
      accentColor: '#00E5FF',
      buttonText: 'Join Discord',
    },
  ];

  return (
    <section id="community" className="relative py-24 bg-[#050505] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#00E5FF] mb-3 font-heading">
            <Sparkles className="w-4 h-4" />
            <span>Community HQ</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-4">
            JOIN THE ADVENTURE
          </h2>
          <p className="text-base text-zinc-300 font-medium">
            Connect directly with Yulky Gamer across official channels, suggest upcoming video ideas, and subscribe on YouTube.
          </p>

          {/* Prominent Subscribe Buttons Cluster */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-8">
            <a
              href={SITE_CONFIG.socials.youtubeSubscribe}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-7 py-3 text-sm font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF0033] to-[#d60029] hover:from-[#ff1a47] hover:to-[#FF0033] rounded-md transition-all shadow-lg shadow-[#FF0033]/30 hover:-translate-y-0.5"
            >
              <Youtube className="w-5 h-5 fill-current" />
              <span>SUBSCRIBE ON YOUTUBE</span>
            </a>

            <a
              href={SITE_CONFIG.socials.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 text-sm font-bold uppercase tracking-wider text-zinc-200 bg-white/5 hover:bg-white/10 hover:text-white rounded-md transition-all border border-white/10"
            >
              <span>VISIT CHANNEL</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Social Channel Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {socialCards.map((channel) => {
            const Icon = channel.icon;
            return (
              <a
                key={channel.name}
                href={channel.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative rounded-xl bg-[#0C101A] hover:bg-[#121624] p-7 border border-white/10 hover:border-white/25 transition-all duration-300 flex flex-col justify-between shadow-lg hover:-translate-y-1"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div
                      className="w-12 h-12 rounded-lg flex items-center justify-center transition-transform group-hover:scale-105"
                      style={{
                        backgroundColor: `${channel.accentColor}18`,
                        color: channel.accentColor,
                        border: `1px solid ${channel.accentColor}40`,
                      }}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <ExternalLink className="w-4 h-4 text-zinc-500 group-hover:text-white transition-colors" />
                  </div>

                  <span className="text-xs text-zinc-400 block mb-1 font-mono">{channel.role}</span>
                  <h3 className="font-heading text-xl font-bold text-white mb-1 group-hover:text-[#00E5FF] transition-colors">
                    {channel.name}
                  </h3>
                  <p className="text-sm text-zinc-400 mb-6 font-mono">{channel.handle}</p>
                </div>

                <div className="pt-4 border-t border-zinc-800/80 flex items-center justify-between text-xs font-semibold text-zinc-200">
                  <span>{channel.buttonText}</span>
                  <span className="text-[#00E5FF]">→</span>
                </div>
              </a>
            );
          })}
        </div>

        {/* Challenge Suggestion Interactive Box */}
        <div className="rounded-2xl bg-gradient-to-br from-[#0F1420] via-[#0B0E16] to-[#07090F] border border-white/10 p-8 sm:p-12 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#FF0033]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#00E5FF]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5 space-y-4">
              <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#FF0033]">
                <Flame className="w-4 h-4 fill-current" />
                <span>Submit an Idea</span>
              </div>
              <h3 className="font-heading text-2xl sm:text-3xl font-extrabold text-white">
                HAVE A CRAZY CHALLENGE IDEA?
              </h3>
              <p className="text-sm text-zinc-300 leading-relaxed">
                Think you have an impossible Minecraft survival rule, a ridiculous redstone physics test, or an extreme hardcore seed? Send your prompt directly to Yulky!
              </p>
              <div className="text-xs text-zinc-400 pt-2 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#00E5FF]" />
                <span>Selected ideas get credited on-screen in the video!</span>
              </div>
            </div>

            <div className="lg:col-span-7">
              {submitted ? (
                <div className="p-8 rounded-xl bg-[#090D16] border border-[#00E5FF]/40 text-center space-y-3 animate-in fade-in zoom-in-95 duration-200">
                  <div className="w-12 h-12 rounded-full bg-[#00E5FF]/10 text-[#00E5FF] flex items-center justify-center mx-auto border border-[#00E5FF]/30">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="font-heading text-lg font-bold text-white">CHALLENGE RECEIVED!</h4>
                  <p className="text-xs text-zinc-300 max-w-md mx-auto">
                    Thanks for submitting! If selected for an upcoming survival series or experiment, your gamer tag will be featured in the intro.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setSubmitted(false);
                      setChallengeText('');
                    }}
                    className="px-4 py-2 text-xs font-semibold text-[#00E5FF] hover:underline"
                  >
                    Submit another challenge
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmitChallenge} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="tag" className="block text-xs font-semibold text-zinc-300 mb-1.5">
                        Your Gamer Tag / Name
                      </label>
                      <input
                        id="tag"
                        type="text"
                        required
                        value={gamerTag}
                        onChange={(e) => setGamerTag(e.target.value)}
                        placeholder="e.g. EnderKnight99"
                        className="w-full px-3.5 py-2.5 rounded-lg bg-[#070A10] border border-white/10 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#00E5FF] focus:ring-1 focus:ring-[#00E5FF] transition-all"
                      />
                    </div>
                    <div>
                      <label htmlFor="topic" className="block text-xs font-semibold text-zinc-300 mb-1.5">
                        Category
                      </label>
                      <select
                        id="topic"
                        className="w-full px-3.5 py-2.5 rounded-lg bg-[#070A10] border border-white/10 text-sm text-zinc-200 focus:outline-none focus:border-[#00E5FF] focus:ring-1 focus:ring-[#00E5FF] transition-all"
                      >
                        <option>Hardcore Survival Constraint</option>
                        <option>Redstone / Physics Experiment</option>
                        <option>Speedrun / Boss Battle</option>
                        <option>Map / Seed Exploration</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="challenge" className="block text-xs font-semibold text-zinc-300 mb-1.5">
                      Describe The Challenge
                    </label>
                    <textarea
                      id="challenge"
                      rows={3}
                      required
                      value={challengeText}
                      onChange={(e) => setChallengeText(e.target.value)}
                      placeholder="e.g. Beat the Nether using only wooden tools and permanent blindfold..."
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#070A10] border border-white/10 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#00E5FF] focus:ring-1 focus:ring-[#00E5FF] transition-all resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-[#FF0033] to-[#d60029] hover:from-[#ff1a47] hover:to-[#FF0033] rounded-lg transition-all shadow-md shadow-[#FF0033]/20"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Challenge to Yulky</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
