import React from 'react';
import { Monitor, Smartphone, ExternalLink, Check, ShieldCheck, ArrowRight } from 'lucide-react';
import { MINECRAFT_PLATFORMS } from '../data/minecraftAccess';

export const GetMinecraft: React.FC = () => {
  return (
    <section id="get-minecraft" className="relative py-24 bg-[#080B12] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#00E5FF] mb-3 font-heading">
            <ShieldCheck className="w-4 h-4" />
            <span>Official Game Releases</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-4">
            GET MINECRAFT
          </h2>
          <p className="text-base text-zinc-300 font-medium">
            Jump into the infinite sandbox world on your favorite device through verified, official Mojang Studios &amp; Microsoft portals.
          </p>
        </div>

        {/* 2-Column Platform Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {MINECRAFT_PLATFORMS.map((platform) => {
            const isPC = platform.id === 'pc-mac';

            return (
              <div
                key={platform.id}
                className="rounded-2xl bg-gradient-to-b from-[#111624] via-[#0D101A] to-[#07090F] border border-white/10 hover:border-[#00E5FF]/40 transition-all duration-300 p-8 sm:p-10 flex flex-col justify-between shadow-2xl relative overflow-hidden group hover:-translate-y-1"
              >
                {/* Ambient Corner Glow */}
                <div
                  className={`absolute top-0 right-0 w-48 h-48 rounded-full blur-3xl pointer-events-none opacity-20 ${
                    isPC ? 'bg-[#00E5FF]' : 'bg-[#FF0033]'
                  }`}
                />

                <div className="space-y-6 relative z-10">
                  {/* Platform Icon & Badge */}
                  <div className="flex items-center justify-between">
                    <div
                      className={`w-14 h-14 rounded-xl flex items-center justify-center border shadow-lg ${
                        isPC
                          ? 'bg-[#00E5FF]/10 text-[#00E5FF] border-[#00E5FF]/30'
                          : 'bg-[#FF0033]/10 text-[#FF0033] border-[#FF0033]/30'
                      }`}
                    >
                      {isPC ? <Monitor className="w-7 h-7" /> : <Smartphone className="w-7 h-7" />}
                    </div>
                    <span className="text-xs font-mono font-semibold px-3 py-1 rounded bg-black/60 border border-white/10 text-zinc-300">
                      {platform.badge}
                    </span>
                  </div>

                  {/* Title & Subtitle */}
                  <div>
                    <h3 className="font-heading text-2xl font-bold text-white mb-1 group-hover:text-[#00E5FF] transition-colors">
                      {platform.title}
                    </h3>
                    <p className="text-xs font-mono text-[#00E5FF]">{platform.subtitle}</p>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-zinc-300 leading-relaxed">
                    {platform.description}
                  </p>

                  {/* Platform Highlights */}
                  <div className="space-y-2 pt-2 border-t border-zinc-800 text-xs text-zinc-300">
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#00E5FF] shrink-0" />
                      <span>{platform.compatibility}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-[#00E5FF] shrink-0" />
                      <span>Regular updates, snapshot testing &amp; realm multiplayer</span>
                    </div>
                  </div>

                  {/* Official Notice */}
                  <p className="text-[11px] text-zinc-400 bg-black/40 p-3 rounded-lg border border-white/5 leading-relaxed">
                    {platform.notice}
                  </p>
                </div>

                {/* Direct Official Action Button */}
                <div className="pt-8 relative z-10">
                  <a
                    href={platform.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-full flex items-center justify-center gap-2.5 py-3.5 px-6 text-xs font-bold uppercase tracking-wider rounded-lg transition-all duration-200 shadow-lg ${
                      isPC
                        ? 'bg-gradient-to-r from-[#00E5FF] to-[#00b4d8] hover:from-white hover:to-[#00E5FF] text-black shadow-[#00E5FF]/20'
                        : 'bg-gradient-to-r from-[#FF0033] to-[#d60029] hover:from-[#ff1a47] hover:to-[#FF0033] text-white shadow-[#FF0033]/25'
                    }`}
                  >
                    <span>{platform.buttonText}</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
