import React, { useState, useEffect } from 'react';
import { Youtube, Menu, X, ExternalLink } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';

interface NavbarProps {
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({ activeSection }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Videos', href: '#videos' },
    { label: 'Shorts', href: '#shorts' },
    { label: 'Resources', href: '#resources' },
    { label: 'Get Minecraft', href: '#get-minecraft' },
    { label: 'Community', href: '#community' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#050505]/95 backdrop-blur-md border-b border-white/10 shadow-lg shadow-black/50 py-3'
          : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6">
          {/* Zone 1: Brand Wordmark */}
          <a
            href="#home"
            onClick={(e) => handleNavClick(e, '#home')}
            className="group flex items-center gap-2.5 text-slate-100 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00E5FF] rounded"
          >
            <div className="relative w-8 h-8 rounded bg-gradient-to-br from-[#101520] to-[#050505] border border-[#00E5FF]/40 flex items-center justify-center overflow-hidden transition-transform group-hover:scale-105">
              <span className="font-heading font-black text-xs text-[#00E5FF] tracking-tighter">
                YG
              </span>
              <div className="absolute inset-0 bg-[#00E5FF]/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="absolute bottom-0 right-0 w-2 h-2 bg-[#FF0033]" />
            </div>

            <span className="font-heading text-lg sm:text-xl font-extrabold tracking-wider bg-gradient-to-r from-white via-slate-100 to-[#00E5FF] bg-clip-text text-transparent">
              {SITE_CONFIG.brand.name}
            </span>
          </a>

          {/* Zone 2: Navigation Links (Desktop) */}
          <nav className="hidden lg:flex items-center gap-5 xl:gap-6 text-sm font-medium">
            {navLinks.map((link) => {
              const isActive = activeSection === link.href.replace('#', '');
              return (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={`relative py-1 transition-colors whitespace-nowrap shrink-0 text-xs xl:text-sm tracking-wide ${
                    isActive
                      ? 'text-[#00E5FF] font-semibold'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#00E5FF] shadow-[0_0_8px_#00E5FF]" />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Zone 3: YouTube Primary Action Button */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <a
              href={SITE_CONFIG.socials.youtubeSubscribe}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-[#FF0033] to-[#cc0029] hover:from-[#ff1a47] hover:to-[#FF0033] rounded-md transition-all duration-200 shadow-md shadow-[#FF0033]/20 hover:shadow-[#FF0033]/40 hover:-translate-y-0.5 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FF0033]"
            >
              <Youtube className="w-4 h-4 text-white fill-current" />
              <span>SUBSCRIBE</span>
              <ExternalLink className="w-3 h-3 opacity-70" />
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center gap-2">
            <a
              href={SITE_CONFIG.socials.youtube}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube Channel"
              className="p-2 text-white bg-[#FF0033]/90 hover:bg-[#FF0033] rounded-md transition-colors"
            >
              <Youtube className="w-4 h-4 fill-current" />
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800/60 rounded-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00E5FF]"
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0A0D14]/98 border-b border-white/10 px-4 pt-3 pb-5 mt-2 space-y-2 shadow-2xl backdrop-blur-xl animate-in slide-in-from-top duration-200">
          <nav className="flex flex-col space-y-1.5">
            {navLinks.map((link) => {
              const isActive = activeSection === link.href.replace('#', '');
              return (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-[#00E5FF]/10 text-[#00E5FF] border border-[#00E5FF]/30 font-semibold'
                      : 'text-zinc-300 hover:bg-zinc-800/50 hover:text-white'
                  }`}
                >
                  {link.label}
                </a>
              );
            })}
          </nav>
          <div className="pt-2 border-t border-zinc-800 flex gap-2">
            <a
              href={SITE_CONFIG.socials.youtubeSubscribe}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-semibold text-white bg-[#FF0033] hover:bg-[#cc0029] rounded-lg transition-colors shadow-md shadow-[#FF0033]/20"
            >
              <Youtube className="w-4 h-4 fill-current" />
              <span>SUBSCRIBE ON YOUTUBE</span>
            </a>
            <a
              href={SITE_CONFIG.socials.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2.5 text-xs font-semibold text-zinc-300 bg-white/5 hover:bg-white/10 rounded-lg border border-white/10"
            >
              Channel
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
