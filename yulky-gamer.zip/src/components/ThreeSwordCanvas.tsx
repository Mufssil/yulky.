import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface ThreeSwordCanvasProps {
  className?: string;
}

export const ThreeSwordCanvas: React.FC<ThreeSwordCanvasProps> = ({ className = '' }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [hasWebGlError, setHasWebGlError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Check WebGL availability
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
      if (!gl) {
        setHasWebGlError(true);
        return;
      }
    } catch {
      setHasWebGlError(true);
      return;
    }

    let animationFrameId: number;
    const width = container.clientWidth || 600;
    const height = container.clientHeight || 600;

    // 1. Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x050505, 0.045);

    // 2. Camera setup
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 8.5);

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;

    container.appendChild(renderer.domElement);
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0x0a101d, 1.2);
    scene.add(ambientLight);

    const cyanKeyLight = new THREE.DirectionalLight(0x00e5ff, 2.8);
    cyanKeyLight.position.set(4, 6, 5);
    scene.add(cyanKeyLight);

    const redRimLight = new THREE.DirectionalLight(0xff0033, 3.2);
    redRimLight.position.set(-5, -4, -2);
    scene.add(redRimLight);

    const coreLight = new THREE.PointLight(0x00e5ff, 1.5, 6);
    coreLight.position.set(0, 0, 1);
    scene.add(coreLight);

    // 5. Build Procedural Minecraft Cyber Sword Group
    const swordGroup = new THREE.Group();

    // Reusable Materials
    const darkNetheriteMat = new THREE.MeshStandardMaterial({
      color: 0x181c24,
      metalness: 0.9,
      roughness: 0.25,
      flatShading: true,
    });

    const obsidianEdgeMat = new THREE.MeshStandardMaterial({
      color: 0x090b10,
      metalness: 0.95,
      roughness: 0.15,
      flatShading: true,
    });

    const cyanRuneMat = new THREE.MeshStandardMaterial({
      color: 0x00e5ff,
      emissive: 0x00c8e6,
      emissiveIntensity: 0.85,
      metalness: 0.2,
      roughness: 0.3,
      flatShading: true,
    });

    const redRuneMat = new THREE.MeshStandardMaterial({
      color: 0xff0033,
      emissive: 0xdd0028,
      emissiveIntensity: 0.9,
      metalness: 0.2,
      roughness: 0.3,
      flatShading: true,
    });

    const hiltLeatherMat = new THREE.MeshStandardMaterial({
      color: 0x1f1717,
      metalness: 0.3,
      roughness: 0.8,
      flatShading: true,
    });

    const goldAccentMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.85,
      roughness: 0.3,
      flatShading: true,
    });

    const blockSize = 0.28;
    const boxGeo = new THREE.BoxGeometry(blockSize, blockSize, blockSize);

    // Helper to add voxel
    const addBlock = (
      x: number,
      y: number,
      z: number,
      mat: THREE.Material,
      scaleX = 1,
      scaleY = 1,
      scaleZ = 1
    ) => {
      const mesh = new THREE.Mesh(boxGeo, mat);
      mesh.position.set(x * blockSize, y * blockSize, z * blockSize);
      mesh.scale.set(scaleX, scaleY, scaleZ);
      swordGroup.add(mesh);
    };

    // Sword Grid definition (Minecraft diagonal sword layout)
    // Grip & Pommel: (-4, -4) up to (-1, -1)
    addBlock(-4, -4, 0, cyanRuneMat, 1.2, 1.2, 1.2); // Pommel gem
    addBlock(-4, -4, 0.4, redRuneMat, 0.6, 0.6, 0.6);
    addBlock(-3, -3, 0, hiltLeatherMat);
    addBlock(-2, -2, 0, hiltLeatherMat);
    addBlock(-1.5, -1.5, 0, darkNetheriteMat);

    // Crossguard wings
    addBlock(-3, -1, 0, darkNetheriteMat);
    addBlock(-3, 0, 0, obsidianEdgeMat);
    addBlock(-4, 0, 0, redRuneMat);
    addBlock(-1, -3, 0, darkNetheriteMat);
    addBlock(0, -3, 0, obsidianEdgeMat);
    addBlock(0, -4, 0, redRuneMat);

    addBlock(-2, -0.5, 0, goldAccentMat);
    addBlock(-0.5, -2, 0, goldAccentMat);
    addBlock(-1, -1, 0, cyanRuneMat, 1.2, 1.2, 1.3); // Core emitter

    // Blade diagonally from (0,0) up to (7,7)
    for (let i = 0; i <= 7; i++) {
      const cx = i;
      const cy = i;

      // Center spine (Alternating cyan and red cyber runes)
      if (i % 2 === 0) {
        addBlock(cx, cy, 0, cyanRuneMat, 0.95, 0.95, 0.9);
      } else {
        addBlock(cx, cy, 0, darkNetheriteMat, 1.0, 1.0, 0.85);
      }

      // Left blade edge
      addBlock(cx - 0.9, cy, 0, obsidianEdgeMat, 0.9, 0.9, 0.8);
      // Right blade edge
      addBlock(cx, cy - 0.9, 0, obsidianEdgeMat, 0.9, 0.9, 0.8);

      // Micro edge glow
      if (i === 2 || i === 5) {
        addBlock(cx - 0.85, cy + 0.3, 0.2, cyanRuneMat, 0.4, 0.4, 0.4);
        addBlock(cx + 0.3, cy - 0.85, -0.2, redRuneMat, 0.4, 0.4, 0.4);
      }
    }

    // Blade tip
    addBlock(8, 8, 0, cyanRuneMat, 1.1, 1.1, 0.9);
    addBlock(7.5, 8.5, 0, obsidianEdgeMat, 0.7, 0.7, 0.7);
    addBlock(8.5, 7.5, 0, obsidianEdgeMat, 0.7, 0.7, 0.7);

    // Center the sword pivot
    swordGroup.position.set(0, 0, 0);
    // Initial angle: slight tilt for heroic presentation
    swordGroup.rotation.z = -Math.PI / 14;
    swordGroup.rotation.x = 0.25;
    swordGroup.rotation.y = 0.35;

    // Shift center of sword mass towards origin
    const box = new THREE.Box3().setFromObject(swordGroup);
    const center = new THREE.Vector3();
    box.getCenter(center);
    swordGroup.position.sub(center);

    const swordWrapper = new THREE.Group();
    swordWrapper.add(swordGroup);
    scene.add(swordWrapper);

    // 6. Atmospheric floating voxel particles / spark motes
    const particleCount = 55;
    const particleGeo = new THREE.BoxGeometry(0.06, 0.06, 0.06);
    const particles: THREE.Mesh[] = [];

    for (let p = 0; p < particleCount; p++) {
      const isRed = Math.random() > 0.65;
      const pMat = new THREE.MeshBasicMaterial({
        color: isRed ? 0xff0033 : 0x00e5ff,
        transparent: true,
        opacity: 0.3 + Math.random() * 0.6,
      });
      const pMesh = new THREE.Mesh(particleGeo, pMat);
      pMesh.position.set(
        (Math.random() - 0.5) * 8,
        (Math.random() - 0.5) * 8,
        (Math.random() - 0.5) * 5
      );
      scene.add(pMesh);
      particles.push(pMesh);
    }

    // 7. Mouse interaction state
    let targetRotX = 0.15;
    let targetRotY = 0.3;
    let mouseX = 0;
    let mouseY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouseX = x;
      mouseY = y;
      targetRotY = 0.35 + x * 0.6;
      targetRotX = 0.15 - y * 0.45;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    // Handle Resize
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    // 8. Animation loop
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Gentle floating hover & continuous slow orbit
      swordWrapper.position.y = Math.sin(elapsedTime * 1.6) * 0.18;
      swordWrapper.position.x = Math.cos(elapsedTime * 0.9) * 0.06;

      // Smooth damping interpolation toward mouse target
      swordWrapper.rotation.y += (targetRotY - swordWrapper.rotation.y) * 0.05;
      swordWrapper.rotation.x += (targetRotX - swordWrapper.rotation.x) * 0.05;

      // Subtle slow yaw oscillation
      swordGroup.rotation.z = -Math.PI / 14 + Math.sin(elapsedTime * 0.8) * 0.05;

      // Particle floating drift
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.position.y += 0.008 + (i % 3) * 0.004;
        p.rotation.x += 0.01;
        p.rotation.y += 0.02;
        if (p.position.y > 4.5) {
          p.position.y = -4.5;
          p.position.x = (Math.random() - 0.5) * 8;
        }
      }

      // Pulsing rune intensity
      const pulse = 0.7 + Math.sin(elapsedTime * 3) * 0.3;
      cyanRuneMat.emissiveIntensity = pulse;
      coreLight.intensity = 1.2 + pulse * 0.6;

      renderer.render(scene, camera);
    };

    animate();
    setIsLoaded(true);

    // WebGL context event listeners
    const canvas = renderer.domElement;
    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setHasWebGlError(true);
    };
    canvas.addEventListener('webglcontextlost', handleContextLost, false);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      resizeObserver.disconnect();
      canvas.removeEventListener('webglcontextlost', handleContextLost);

      // Dispose
      boxGeo.dispose();
      particleGeo.dispose();
      darkNetheriteMat.dispose();
      obsidianEdgeMat.dispose();
      cyanRuneMat.dispose();
      redRuneMat.dispose();
      hiltLeatherMat.dispose();
      goldAccentMat.dispose();

      renderer.dispose();
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  if (hasWebGlError) {
    return (
      <div className={`flex items-center justify-center p-8 ${className}`}>
        {/* Polished SVG/CSS Fallback for environments where WebGL is unsupported */}
        <div className="relative flex flex-col items-center justify-center p-8 rounded-2xl border border-[#00E5FF]/20 bg-[#0A0D14]/90 backdrop-blur-md">
          <div className="relative w-64 h-64 flex items-center justify-center">
            {/* Ambient Back Glow */}
            <div className="absolute inset-0 bg-radial from-[#00E5FF]/20 via-[#FF0033]/15 to-transparent rounded-full filter blur-xl animate-pulse" />
            <svg
              viewBox="0 0 100 100"
              className="w-52 h-52 filter drop-shadow-[0_0_15px_#00E5FF]"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Voxel Sword SVG Fallback */}
              <rect x="75" y="15" width="8" height="8" fill="#00E5FF" />
              <rect x="67" y="23" width="8" height="8" fill="#14171F" stroke="#00E5FF" strokeWidth="1" />
              <rect x="59" y="31" width="8" height="8" fill="#00E5FF" />
              <rect x="51" y="39" width="8" height="8" fill="#14171F" stroke="#00E5FF" strokeWidth="1" />
              <rect x="43" y="47" width="8" height="8" fill="#00E5FF" />
              <rect x="35" y="55" width="8" height="8" fill="#14171F" stroke="#00E5FF" strokeWidth="1" />
              {/* Crossguard */}
              <rect x="23" y="55" width="8" height="8" fill="#FF0033" />
              <rect x="35" y="67" width="8" height="8" fill="#FF0033" />
              <rect x="27" y="63" width="8" height="8" fill="#14171F" stroke="#00E5FF" strokeWidth="1" />
              {/* Handle */}
              <rect x="19" y="71" width="8" height="8" fill="#1B1F29" />
              <rect x="11" y="79" width="8" height="8" fill="#00E5FF" />
            </svg>
          </div>
          <span className="text-xs uppercase tracking-widest text-[#00E5FF] font-medium mt-2">
            Cyber Sword Model
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative w-full h-full min-h-[420px] lg:min-h-[580px] ${className}`}>
      {/* 3D WebGL Canvas Mount */}
      <div ref={containerRef} className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Interactive Helper Indicator */}
      <div className="absolute bottom-4 right-4 z-10 pointer-events-none hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#050505]/80 border border-white/10 backdrop-blur-sm text-[11px] text-zinc-400">
        <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF] animate-ping" />
        <span>Interactive 3D Voxel Core · Move cursor to rotate</span>
      </div>
    </div>
  );
};
