import React from 'react';
import { ExternalLink, Layers, Sparkles, Map, Package, Wrench, ShieldAlert } from 'lucide-react';
import { MINECRAFT_RESOURCES } from '../data/downloads';

export const Downloads: React.FC = () => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'mods':
        return <Wrench className="w-7 h-7 text-[#00E5FF]" />;
      case 'resourcepacks':
        return <Layers className="w-7 h-7 text-[#00E5FF]" />;
      case 'maps':
        return <Map className="w-7 h-7 text-[#FF0033]" />;
      case 'addons':
      default:
        return <Package className="w-7 h-7 text-[#00E5FF]" />;
    }
  };

  return (
    <section id="resources" className="relative py-24 bg-[#050505] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#00E5FF] mb-2 font-heading">
              <Sparkles className="w-4 h-4" />
              <span>Modrinth Powered Hub</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white">
              MINECRAFT RESOURCE HUB
            </h2>
            <p className="text-sm text-zinc-400 mt-2 max-w-xl">
              Curated access to community mods, high-fidelity resource packs, custom adventure maps, and datapacks on Modrinth.
            </p>
          </div>

          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-md bg-[#101522] border border-white/10 text-xs text-zinc-400">
            <span className="w-2 h-2 rounded-full bg-[#00E5FF]" />
            <span>Official Modrinth Platform Links</span>
          </div>
        </div>

        {/* Resource Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {MINECRAFT_RESOURCES.map((item) => (
            <div
              key={item.id}
              className="rounded-xl bg-[#0D111A] border border-white/10 hover:border-[#00E5FF]/40 transition-all duration-300 flex flex-col justify-between overflow-hidden shadow-xl group hover:-translate-y-1.5"
            >
              <div>
                {/* Visual Header */}
                <div className="relative h-40 bg-[#07090F] overflow-hidden flex items-center justify-center p-4">
                  <div className="absolute inset-0 bg-gradient-to-b from-[#141A28] via-[#0A0D15] to-[#07090F]" />
                  <div className="absolute inset-0 bg-minecraft-grid opacity-20" />

                  {/* Themed Icon Container */}
                  <div className="relative z-10 w-16 h-16 rounded-xl bg-[#121724] border border-[#00E5FF]/30 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                    {getIcon(item.iconName)}
                  </div>

                  {/* Badge */}
                  <div className="absolute top-3 left-3 text-[11px] font-heading font-semibold text-zinc-200 bg-black/80 px-2.5 py-0.5 rounded border border-white/10">
                    {item.badge}
                  </div>

                  {/* Platform Indicator */}
                  <div className="absolute bottom-3 right-3 text-[10px] font-mono text-[#00E5FF] bg-black/70 px-2 py-0.5 rounded">
                    {item.platform}
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-3">
                  <h3 className="font-heading text-lg font-bold text-white group-hover:text-[#00E5FF] transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-xs text-zinc-400 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Action */}
              <div className="p-5 pt-0">
                <a
                  href={item.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-bold uppercase rounded bg-gradient-to-r from-[#00E5FF] to-[#00b4d8] hover:from-white hover:to-[#00E5FF] text-black shadow-md shadow-[#00E5FF]/20 transition-all duration-200 font-button"
                >
                  <span>EXPLORE NOW</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Platform Attribution & Disclaimer Banner */}
        <div className="p-5 rounded-xl bg-[#090D16] border border-white/10 flex flex-col sm:flex-row items-center gap-3 text-xs text-zinc-400">
          <ShieldAlert className="w-5 h-5 text-[#00E5FF] shrink-0" />
          <p className="leading-relaxed">
            <strong className="text-zinc-200 font-semibold">Third-Party Hosting Notice:</strong> All mods, texture packs, maps, and datapacks are hosted independently on the official Modrinth open platform. Downloads are provided by Modrinth and their respective community creators.
          </p>
        </div>
      </div>
    </section>
  );
};
