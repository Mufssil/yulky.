import React from 'react';
import { Youtube, Play, ArrowDown, Flame, Sparkles, ExternalLink } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';
import { SuppliedSwordVisual } from './SuppliedSwordVisual';

export const Hero: React.FC = () => {
  const handleScrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-24 pb-16 lg:py-0 overflow-hidden bg-[#050505]"
    >
      {/* Layered Background: Minecraft-inspired dark atmosphere */}
      <div className="absolute inset-0 pointer-events-none bg-minecraft-grid opacity-25" />

      {/* Atmospheric Energy Glows */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-[#00E5FF]/8 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 translate-x-1/4 translate-y-1/4 w-[550px] h-[550px] bg-[#FF0033]/8 rounded-full blur-[140px] pointer-events-none" />

      {/* Hero Content Container */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10 py-12 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Headlines & CTA */}
          <div className="lg:col-span-7 flex flex-col items-start text-left space-y-6">
            {/* Brand Kicker */}
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-zinc-400">
              <span className="text-[#00E5FF] font-heading">Official Channel Portal</span>
              <span aria-hidden="true" className="text-zinc-600">·</span>
              <span className="text-zinc-300">@BESTERGAMERZ99</span>
              <span aria-hidden="true" className="text-zinc-600">·</span>
              <span className="text-[#FF0033]">Survival Epics</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-heading text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-[1.08] max-w-2xl">
              ENTER THE WORLD OF{' '}
              <span className="relative inline-block text-transparent bg-clip-text bg-gradient-to-r from-white via-[#00E5FF] to-[#00B4D8]">
                YULKY GAMER
              </span>
            </h1>

            {/* Supporting Text */}
            <p className="text-lg sm:text-xl text-zinc-300 font-medium leading-relaxed max-w-xl">
              {SITE_CONFIG.brand.tagline}
            </p>

            <p className="text-sm sm:text-base text-zinc-400 leading-relaxed max-w-lg">
              {SITE_CONFIG.brand.shortBio}
            </p>

            {/* Prominent Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-2 w-full sm:w-auto">
              {/* Primary YouTube Subscribe Button */}
              <a
                href={SITE_CONFIG.socials.youtubeSubscribe}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm font-bold tracking-wide uppercase text-white bg-gradient-to-r from-[#FF0033] to-[#d60029] hover:from-[#ff1a47] hover:to-[#FF0033] rounded-md transition-all duration-200 shadow-lg shadow-[#FF0033]/25 hover:shadow-[#FF0033]/45 hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FF0033]"
              >
                <Youtube className="w-4 h-4 fill-current" />
                <span>SUBSCRIBE ON YOUTUBE</span>
              </a>

              {/* Secondary Explore Videos Button */}
              <button
                type="button"
                onClick={() => handleScrollTo('videos')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-sm font-bold tracking-wide uppercase text-zinc-100 bg-[#121620] hover:bg-[#1A202C] border border-[#00E5FF]/30 hover:border-[#00E5FF]/60 rounded-md transition-all duration-200 shadow-sm hover:-translate-y-0.5 text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00E5FF]"
              >
                <Play className="w-4 h-4 fill-current text-[#00E5FF]" />
                <span>EXPLORE VIDEOS</span>
              </button>

              {/* Visit Channel Button */}
              <a
                href={SITE_CONFIG.socials.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-bold tracking-wide uppercase text-zinc-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-md transition-all duration-200 border border-white/10 text-center"
              >
                <span>VISIT CHANNEL</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-60" />
              </a>
            </div>

            {/* Quick Highlights Strip */}
            <div className="pt-4 border-t border-zinc-800/80 w-full flex flex-wrap items-center gap-y-2 gap-x-5 text-xs text-zinc-400 font-medium">
              <span className="flex items-center gap-1.5 text-zinc-300">
                <Flame className="w-3.5 h-3.5 text-[#FF0033]" />
                Battle Pie Hardcore Server
              </span>
              <span aria-hidden="true" className="text-zinc-600">/</span>
              <span className="flex items-center gap-1.5 text-zinc-300">
                <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
                Survival Series Episodes
              </span>
              <span aria-hidden="true" className="text-zinc-600">/</span>
              <span>Daily YouTube Shorts</span>
            </div>
          </div>

          {/* Right Column: Hero Visual with Supplied Diamond Sword */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            <div className="relative w-full max-w-[500px] aspect-square rounded-2xl bg-[#090C12]/50 border border-white/10 p-4 backdrop-blur-[4px] shadow-2xl">
              <SuppliedSwordVisual className="w-full h-full" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Scroll Anchor */}
      <button
        type="button"
        onClick={() => handleScrollTo('about')}
        aria-label="Scroll to About section"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center gap-1 text-zinc-500 hover:text-[#00E5FF] transition-colors focus-visible:outline-none"
      >
        <span className="text-[10px] uppercase font-semibold tracking-widest font-heading">SCROLL</span>
        <ArrowDown className="w-4 h-4 animate-bounce" />
      </button>
    </section>
  );
};
