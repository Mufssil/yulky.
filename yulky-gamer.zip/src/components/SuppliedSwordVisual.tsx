import React, { useState, useEffect, useRef } from 'react';

interface SuppliedSwordVisualProps {
  className?: string;
}

export const SuppliedSwordVisual: React.FC<SuppliedSwordVisualProps> = ({ className = '' }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = (e.clientX - (rect.left + rect.width / 2)) / (rect.width / 2);
      const y = (e.clientY - (rect.top + rect.height / 2)) / (rect.height / 2);
      setMousePos({
        x: Math.max(-1, Math.min(1, x)),
        y: Math.max(-1, Math.min(1, y)),
      });
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Compute smooth tilt angles
  const rotateY = mousePos.x * 12;
  const rotateX = -mousePos.y * 10;

  return (
    <div
      ref={containerRef}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setMousePos({ x: 0, y: 0 });
      }}
      className={`relative w-full h-full min-h-[440px] lg:min-h-[560px] flex items-center justify-center select-none ${className}`}
      style={{ perspective: '1000px' }}
    >
      {/* Cinematic Ambient Glow Blooms */}
      <div className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full bg-gradient-to-tr from-[#00E5FF]/20 via-[#FF0033]/15 to-transparent blur-[80px] pointer-events-none animate-pulse" />
      <div className="absolute w-48 h-48 rounded-full bg-[#00E5FF]/15 blur-[50px] pointer-events-none" />

      {/* Floating Sparkles & Minecraft Voxel Sparks */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(12)].map((_, i) => (
          <span
            key={i}
            className={`absolute block rounded-sm ${
              i % 3 === 0 ? 'bg-[#FF0033]' : 'bg-[#00E5FF]'
            } opacity-60 animate-bounce`}
            style={{
              width: `${(i % 3) + 3}px`,
              height: `${(i % 3) + 3}px`,
              left: `${15 + (i * 7) % 70}%`,
              top: `${20 + (i * 11) % 65}%`,
              animationDuration: `${2.5 + (i % 4) * 0.8}s`,
              animationDelay: `${(i % 5) * 0.4}s`,
            }}
          />
        ))}
      </div>

      {/* Sword Stage Holder with 3D Parallax Tilt & Floating Animation */}
      <div
        className="relative z-10 w-full max-w-[380px] sm:max-w-[440px] aspect-square flex items-center justify-center transition-transform duration-300 ease-out"
        style={{
          transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(${
            isHovered ? '-8px' : '0px'
          })`,
          transformStyle: 'preserve-3d',
        }}
      >
        {/* Subtle Pedestal Halo */}
        <div className="absolute bottom-6 w-44 h-12 bg-radial from-[#00E5FF]/30 to-transparent blur-md rounded-full pointer-events-none" />

        {/* The Exact Pixel-Clean Minecraft Diamond Sword Asset */}
        <img
          src="/images/supplied-sword.svg"
          alt="Yulky Gamer Official Minecraft Diamond Sword"
          className="w-full h-full object-contain filter drop-shadow-[0_0_20px_rgba(0,229,255,0.45)] drop-shadow-[0_0_40px_rgba(255,0,51,0.25)] transition-all duration-300"
          style={{
            imageRendering: 'pixelated',
          }}
          loading="eager"
        />

        {/* Dynamic Energy Rim Highlight */}
        <div
          className="absolute inset-0 pointer-events-none rounded-full opacity-30"
          style={{
            background: `radial-gradient(circle at ${50 + mousePos.x * 25}% ${
              50 + mousePos.y * 25
            }%, rgba(0, 229, 255, 0.25), transparent 70%)`,
          }}
        />
      </div>

      {/* Interactive Helper Indicator */}
      <div className="absolute bottom-4 right-4 z-20 hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#050505]/85 border border-white/10 backdrop-blur-sm text-[11px] text-zinc-400">
        <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF] animate-ping" />
        <span>Supplied Asset · Interactive 3D Parallax Core</span>
      </div>
    </div>
  );
};
