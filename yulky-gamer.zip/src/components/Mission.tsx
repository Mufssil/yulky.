import React from 'react';
import { Compass, Flame, ShieldAlert, HeartHandshake } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';

export const Mission: React.FC = () => {
  return (
    <section className="relative py-28 bg-[#050505] overflow-hidden border-t border-white/5">
      {/* Cinematic Layered Minecraft Grid & Vignette */}
      <div className="absolute inset-0 pointer-events-none bg-minecraft-grid opacity-20" />
      <div className="absolute inset-0 bg-radial-vignette opacity-70 pointer-events-none" />

      {/* Atmospheric Energy Blooms */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-r from-[#00E5FF]/10 via-transparent to-[#FF0033]/10 blur-[120px] pointer-events-none" />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center z-10">
        {/* Section Tag */}
        <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#FF0033] mb-4 font-heading">
          <Flame className="w-4 h-4 fill-current" />
          <span>Creator Philosophy</span>
        </div>

        {/* Section Heading */}
        <h2 className="font-heading text-3xl sm:text-5xl font-black tracking-tight text-white mb-6">
          THE MISSION
        </h2>

        {/* Supporting Signature Message */}
        <p className="font-heading text-xl sm:text-2xl text-transparent bg-clip-text bg-gradient-to-r from-[#00E5FF] via-white to-[#00E5FF] font-semibold mb-8 max-w-3xl mx-auto leading-relaxed">
          &ldquo;{SITE_CONFIG.brand.missionQuote}&rdquo;
        </p>

        {/* Brand Mission Body */}
        <p className="text-base sm:text-lg text-zinc-300 max-w-2xl mx-auto leading-relaxed font-medium mb-12">
          {SITE_CONFIG.brand.missionStatement}
        </p>

        {/* Cinematic 3-Item Mission Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-left pt-6 border-t border-zinc-800">
          <div className="p-5 rounded-xl bg-[#0B0E14]/70 border border-white/5">
            <div className="w-8 h-8 rounded bg-[#00E5FF]/10 text-[#00E5FF] flex items-center justify-center mb-3">
              <Compass className="w-4 h-4" />
            </div>
            <h4 className="font-heading text-sm font-bold text-white mb-1">Curiosity First</h4>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Diving deep into unexplored seeds, hidden redstone mechanics, and unexpected sandbox outcomes.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-[#0B0E14]/70 border border-white/5">
            <div className="w-8 h-8 rounded bg-[#FF0033]/10 text-[#FF0033] flex items-center justify-center mb-3">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <h4 className="font-heading text-sm font-bold text-white mb-1">True Hardcore Spirit</h4>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Never faking survival outcomes. When the stakes are real, every escape feels genuinely earned.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-[#0B0E14]/70 border border-white/5">
            <div className="w-8 h-8 rounded bg-[#00E5FF]/10 text-[#00E5FF] flex items-center justify-center mb-3">
              <HeartHandshake className="w-4 h-4" />
            </div>
            <h4 className="font-heading text-sm font-bold text-white mb-1">Community Fuel</h4>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Taking challenges submitted by subscribers and giving back custom maps and texture packs.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
