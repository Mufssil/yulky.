import { MinecraftPlatformItem } from '../types';

export const MINECRAFT_PLATFORMS: MinecraftPlatformItem[] = [
  {
    id: 'pc-mac',
    platform: 'PC / Mac',
    title: 'Minecraft Java & Bedrock Edition',
    subtitle: 'Windows 10/11, macOS & Linux',
    description:
      'The definitive desktop Minecraft experience. Includes both Java and Bedrock editions in a single unified launcher with full modding, custom shaders, and cross-platform multiplayer support.',
    link: 'https://www.minecraft.net/download',
    buttonText: 'GET MINECRAFT FOR PC',
    badge: 'Official Desktop Release',
    compatibility: 'Windows 10/11 · macOS 10.15+ · Linux',
    notice: 'Official launcher from Mojang Studios & Microsoft. Pricing, system specifications, and account licensing depend directly on Minecraft.net.',
  },
  {
    id: 'mobile',
    platform: 'Mobile',
    title: 'Minecraft Bedrock Mobile',
    subtitle: 'iOS & Android via Official Stores',
    description:
      'Take your worlds anywhere. Cross-play seamlessly with friends on console and PC with optimized touch controls, external controller support, and cloud realm sync.',
    link: 'https://www.minecraft.net/',
    buttonText: 'EXPLORE MINECRAFT MOBILE',
    badge: 'App Store & Google Play',
    compatibility: 'iOS (App Store) · Android (Google Play)',
    notice: 'Visit the official Minecraft portal to find verified App Store and Google Play store links. Never download third-party or untrusted APK packages.',
  },
];
