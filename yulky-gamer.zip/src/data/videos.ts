import { VideoItem, ShortItem } from '../types';

/**
 * EXACT LONG-FORM VIDEOS FROM YULKY GAMER (@BESTERGAMERZ99)
 * Fetched directly from YouTube metadata with maxres / hq thumbnail fallbacks.
 */
export const LONG_FORM_VIDEOS: VideoItem[] = [
  {
    id: 'ryi4ZWwvjWM',
    title: 'FIRST DAY in Minecraft BATTLE PIE! Server Itna HARD Hoga Socha Nahi Tha… 💀🔥Episode #1',
    description: 'Starting out on the extreme Minecraft Battle Pie server! First day survival was insane.',
    youtubeUrl: 'https://youtu.be/ryi4ZWwvjWM',
    embedId: 'ryi4ZWwvjWM',
    maxresThumbnail: 'https://img.youtube.com/vi/ryi4ZWwvjWM/maxresdefault.jpg',
    hqThumbnail: 'https://img.youtube.com/vi/ryi4ZWwvjWM/hqdefault.jpg',
    category: 'Minecraft Survival',
  },
  {
    id: 'tdsB8MJLGEk',
    title: 'Minecraft Survival Series EP1 – First Day Survival | Best Hindi Survival Gameplay |',
    description: 'The beginning of our ultimate Minecraft Survival journey! Gathering basic gear, establishing our first shelter, and surviving the first night.',
    youtubeUrl: 'https://youtu.be/tdsB8MJLGEk',
    embedId: 'tdsB8MJLGEk',
    maxresThumbnail: 'https://img.youtube.com/vi/tdsB8MJLGEk/maxresdefault.jpg',
    hqThumbnail: 'https://img.youtube.com/vi/tdsB8MJLGEk/hqdefault.jpg',
    category: 'Survival Series',
  },
  {
    id: 'qJmtVO56jcc',
    title: "Can I Survive Minecraft's Most Impossible Parkour?",
    description: 'Testing precision jumps, momentum maneuvers, and dizzying heights in Minecraft’s hardest parkour gauntlet.',
    youtubeUrl: 'https://youtu.be/qJmtVO56jcc',
    embedId: 'qJmtVO56jcc',
    maxresThumbnail: 'https://img.youtube.com/vi/qJmtVO56jcc/maxresdefault.jpg',
    hqThumbnail: 'https://img.youtube.com/vi/qJmtVO56jcc/hqdefault.jpg',
    category: 'Epic Challenges',
  },
];

/**
 * EXACT YOUTUBE SHORTS (9:16 VERTICAL FORMAT)
 */
export const SHORTS_VIDEOS: ShortItem[] = [
  {
    id: 'UbfZyHipy0k',
    title: 'TNT + Creeper bhi fail 😳 ye wall kaise? #minecraft #gaming #minecraftbuilding #funny',
    youtubeUrl: 'https://youtube.com/shorts/UbfZyHipy0k',
    embedId: 'UbfZyHipy0k',
    maxresThumbnail: 'https://img.youtube.com/vi/UbfZyHipy0k/maxresdefault.jpg',
    hqThumbnail: 'https://img.youtube.com/vi/UbfZyHipy0k/hqdefault.jpg',
  },
  {
    id: 'o6W5iSGvDtE',
    title: 'Creeper Ki Awaaz Kaise Record Hui? 😳 Minecraft Mobs Sound Secret!#minecraft #secret',
    youtubeUrl: 'https://youtube.com/shorts/o6W5iSGvDtE',
    embedId: 'o6W5iSGvDtE',
    maxresThumbnail: 'https://img.youtube.com/vi/o6W5iSGvDtE/maxresdefault.jpg',
    hqThumbnail: 'https://img.youtube.com/vi/o6W5iSGvDtE/hqdefault.jpg',
  },
  {
    id: 'Dvt7wVHrdmc',
    title: 'Ye Minecraft Mob DAMAGE Hi Nahi Leta 😳 | Time Freeze Proof',
    youtubeUrl: 'https://youtube.com/shorts/Dvt7wVHrdmc',
    embedId: 'Dvt7wVHrdmc',
    maxresThumbnail: 'https://img.youtube.com/vi/Dvt7wVHrdmc/maxresdefault.jpg',
    hqThumbnail: 'https://img.youtube.com/vi/Dvt7wVHrdmc/hqdefault.jpg',
  },
  {
    id: '7uMlkKfCztM',
    title: 'Minecraft Prison Escape in 60 Seconds 😳 | Stuck in Jail! #Shorts',
    youtubeUrl: 'https://youtube.com/shorts/7uMlkKfCztM',
    embedId: '7uMlkKfCztM',
    maxresThumbnail: 'https://img.youtube.com/vi/7uMlkKfCztM/maxresdefault.jpg',
    hqThumbnail: 'https://img.youtube.com/vi/7uMlkKfCztM/hqdefault.jpg',
  },
];
