import { ResourceItem } from '../types';

export const MINECRAFT_RESOURCES: ResourceItem[] = [
  {
    id: 'res-mods',
    title: 'Mods & Performance',
    description: 'Discover game-changing Minecraft mods, optimization engines, and gameplay enhancements on Modrinth.',
    link: 'https://modrinth.com/mods',
    platform: 'Modrinth',
    badge: 'Enhancements',
    iconName: 'mods',
  },
  {
    id: 'res-packs',
    title: 'Resource Packs',
    description: 'Explore custom textures, dark-mode HUDs, 3D item models, and visual upgrades curated for sandbox explorers.',
    link: 'https://modrinth.com/resourcepacks',
    platform: 'Modrinth',
    badge: 'Visuals & UI',
    iconName: 'resourcepacks',
  },
  {
    id: 'res-maps',
    title: 'Minecraft Maps',
    description: 'Discover epic custom adventure maps, parkour runs, survival worlds, and community puzzle arenas.',
    link: 'https://modrinth.com/discover/maps',
    platform: 'Modrinth',
    badge: 'Worlds & Parkour',
    iconName: 'maps',
  },
  {
    id: 'res-addons',
    title: 'Add-ons & Community Packs',
    description: 'Explore custom datapacks, server plugins, shaders, and extra Minecraft community content.',
    link: 'https://modrinth.com/datapacks',
    platform: 'Modrinth',
    badge: 'Datapacks & Extras',
    iconName: 'addons',
  },
];
