export interface VideoItem {
  id: string;
  title: string;
  description?: string;
  youtubeUrl: string;
  embedId: string;
  maxresThumbnail: string;
  hqThumbnail: string;
  category?: string;
}

export interface ShortItem {
  id: string;
  title: string;
  youtubeUrl: string;
  embedId: string;
  maxresThumbnail: string;
  hqThumbnail: string;
}

export interface ResourceItem {
  id: string;
  title: string;
  description: string;
  link: string;
  platform: string;
  badge: string;
  iconName: 'mods' | 'resourcepacks' | 'maps' | 'addons';
}

export interface MinecraftPlatformItem {
  id: string;
  platform: 'PC / Mac' | 'Mobile';
  title: string;
  subtitle: string;
  description: string;
  link: string;
  buttonText: string;
  badge: string;
  compatibility: string;
  notice: string;
}
